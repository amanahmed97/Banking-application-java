public enum AccountType {
    CHECKING,
    SAVING,
    SECURITY,
    LOAN
}
