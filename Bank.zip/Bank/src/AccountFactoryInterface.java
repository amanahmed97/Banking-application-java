public interface AccountFactoryInterface {
    
    Account createAccount(); 
}
