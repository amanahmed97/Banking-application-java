public enum CurrencyType {
    USD,
    INR, //Rupee
    GBP, //Pound
    CNY //Yuan
}
