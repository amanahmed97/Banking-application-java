import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

public class Tst {
    public static void main(String[] args){
        LocalDate date = LocalDate.now();
        String tempS = date.toString();
        LocalDate test = LocalDate.parse(tempS);
        System.out.println(date + "," + tempS + "," + test);
    }
}
