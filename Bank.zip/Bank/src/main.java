public class main {
    //instantiate ATM
    //instantiate BankManager
}
